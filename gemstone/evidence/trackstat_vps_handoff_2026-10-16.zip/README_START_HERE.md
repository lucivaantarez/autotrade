# TrackStat VPS handoff — 2026-10-16

## Goal
Replace incorrect VPS-generated `trackstat.lua` with the attached **tested V21 source** as the baseline. Read only the local player’s replicated game data, without opening StarRewards GUI. Scanner should retry when started before game initialization and continue every 2 seconds while other scripts run. Console: full YYYY-MM-DD HH:MM:SS, changes only, 60-second heartbeat.

## Verified evidence
- V20 dump: Fsys `ClientData` loaded; `new:StarRewardsDB` loaded. `ClientData.get_data()` returned a table indexed by player names. Select ONLY `data[Players.LocalPlayer.Name]`; do not scan or publish other players' data.
- Local-player fields: `stars=3`, `daily_login_manager.streak=1`, `daily_login_manager.longest_streak=2`, `star_rewards_manager.claimed=true`, `star_rewards_manager.current_goal='star_egg'`, `star_rewards_manager.next_claim_timestamp` exists.
- `new:StarRewardsDB.star_egg.price=28`, `item_kind='star_rewards_2026_gemstone_egg'`.
- V21 output `status=READY`, `stars=3`, `egg_price=28`, `stars_remaining=25`, `daily=CLAIMED`, `daily_streak=1`.
- `stars/egg_price` is purchasing power, NOT lifetime egg progress. Do not label it as historical progress.
- V21 TXT and JSON are local files only; there is NO HTTP sync in V21. Existing `observed_at` and `observed_unix` indicate local observation, not server receipt.

## VPS / web integration to implement
1. Preserve V21 scanner and its no-GUI, read-only behavior; verify with existing logs and source before changing.
2. Accept compact per-account reports through an authenticated HTTPS endpoint (design and implement on VPS); NEVER transmit passwords, Roblox cookies, executor keys, or unrelated player data. Use per-device credential stored server-side securely; add replay protection, payload validation and rate limiting.
3. Store `observed_unix` (client observation) and server-generated `last_sync_at` (receipt time, UTC) separately; dashboard renders `Last Sync` in user's timezone (Asia/Jakarta) and `Last Seen` from server time.
4. Suggested transport: scan every 2s; upload on state changes or every 30–60s. Retry failed HTTP with bounded exponential backoff and jitter; do not block scan. Avoid logging secrets.
5. Dashboard status should be derived from server receipt age, not from `READY` alone; distinguish READY, PARTIAL, STALE/OFFLINE. Configurable freshness threshold (example: >60s stale).
6. Deduplicate accounts and avoid overwriting fresh reports with older ones. Store normalized fields: account alias/id, stars, egg_price, stars_remaining, daily_streak, longest_streak, claimed, daily, current_goal, next_claim_timestamp, observed_unix, last_sync_at, source, version.
7. Existing V21 code saves local TXT+JSON every successful scan, and logs on changes/heartbeat. It does NOT prove simultaneous ZekeHub operation or updates after claim. Do not assert those as verified.
8. Protect account privacy: raw V19/V20 diagnostics contain other players' usernames. Use them locally for engineering; do not upload raw logs to public web or expose in dashboard. Redact before wider sharing.

## Source precedence
`trackstat_v21.lua` = working baseline. `trackstat_result.json/.txt` = actual successful output. `gemstone_v20_dump.txt` = field/DB evidence. V19/V17 = historical diagnostics; previous versions are reference only. The nested `gemstone_evidence_for_hermes.zip` contains older diagnostics and notes. Do not invent missing V16 raw execution log.

## Suggested implementation acceptance checks
- Early startup => WAITING then READY without manual restart.
- Only LocalPlayer data selected.
- Full timestamp and no 2-second console spam.
- Web Last Sync changes only on successful backend receipt; Last Seen grows when no reports arrive.
- Backend restart preserves last report; delayed packets do not overwrite newer data.
- No accidental Swap completion signals from TrackStat; read-only remains read-only.
