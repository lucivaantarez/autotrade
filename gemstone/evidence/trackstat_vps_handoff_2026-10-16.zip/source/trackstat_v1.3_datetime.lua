-- TrackStat v1.3: read-only Adopt Me Star Rewards GUI tracker
-- No clicks, purchases, remote calls, or hooks.
-- Output: trackstat_result.txt and trackstat_result.json
local Players = game:GetService('Players')
local HttpService = game:GetService('HttpService')
local player = Players.LocalPlayer
local CFG = {scan=2, stable=0.5, samples=3, heartbeat=60}
local BASE = 'StarRewardsApp.Static.Folder.Main.Backing.Content'
local PATH = {
  app='StarRewardsApp',
  claim=BASE..'.ClaimScreen.ClaimButton.Button',
  claim_screen=BASE..'.ClaimScreen',
  main=BASE..'.MainScreen',
  progress=BASE..'.MainScreen.GoalContainer.Content.GoalCount.Count',
  stars=BASE..'.Header.CurrencyDisplay.Count',
  shop=BASE..'.ShopScreen',
}
local function node(root, p)
  local cur=root
  for part in p:gmatch('[^.]+') do
    if not cur then return nil end
    cur=cur:FindFirstChild(part)
  end
  return cur
end
local function textOf(obj)
  if not obj then return nil end
  if obj:IsA('TextLabel') or obj:IsA('TextButton') or obj:IsA('TextBox') then return obj.Text end
  local t=obj:FindFirstChild('Text')
  if t and (t:IsA('TextLabel') or t:IsA('TextButton') or t:IsA('TextBox')) then return t.Text end
  return nil
end
local function visible(obj, gui)
  if not obj then return false end
  local cur=obj
  while cur and cur~=gui do
    if cur:IsA('GuiObject') and not cur.Visible then return false end
    if cur:IsA('ScreenGui') and not cur.Enabled then return false end
    cur=cur.Parent
  end
  return cur==gui
end
local function num(s)
  if type(s)~='string' then return nil end
  local cleaned=s:gsub(',',''):gsub('%s','')
  return tonumber(cleaned:match('^%d+$') and cleaned or '')
end
local function progressOf(s)
  if type(s)~='string' then return nil,nil end
  local a,b=s:match('(%d+)%s*/%s*(%d+)')
  return tonumber(a),tonumber(b)
end
local function read()
  local gui=player and player:FindFirstChildOfClass('PlayerGui')
  local r={username=player and player.Name or 'unknown', stars=nil, gemstone_progress=nil,
    gemstone_target=nil, daily_reward='UNKNOWN', claim_visible=false,
    source='GUI', reason=nil, timestamp=os.time()}
  if not gui then r.reason='PlayerGui missing'; return r end
  local app=node(gui,PATH.app)
  if not app then r.reason='StarRewardsApp not instantiated'; return r end
  -- In prior recordings Count is sometimes a container whose Text child holds the number.
  local starNode=node(gui,PATH.stars)
  r.stars=num(textOf(starNode))
  local progressNode=node(gui,PATH.progress)
  r.gemstone_progress,r.gemstone_target=progressOf(textOf(progressNode))
  -- Search only the known Star Rewards subtree for fallback display labels.
  if r.gemstone_progress==nil or r.stars==nil then
    for _,obj in ipairs(app:GetDescendants()) do
      if obj:IsA('TextLabel') or obj:IsA('TextButton') then
        local full=obj:GetFullName()
        if r.gemstone_progress==nil and (full:find('GoalCount',1,true) or full:find('GoalContainer',1,true)) then
          local a,b=progressOf(obj.Text)
          if a and b then r.gemstone_progress,r.gemstone_target=a,b end
        end
        if r.stars==nil and full:find('CurrencyDisplay',1,true) then
          local v=num(obj.Text)
          if v~=nil then r.stars=v end
        end
      end
    end
  end
  r.claim_visible=visible(node(gui,PATH.claim),gui)
  if r.claim_visible then
    r.daily_reward='AVAILABLE'
  elseif visible(node(gui,PATH.main),gui) then
    -- The presence of MainScreen is not by itself proof of a successful claim.
    r.daily_reward='NOT_AVAILABLE_ON_SCREEN'
  end
  -- Detect checklist in reward card only as supplementary evidence; do not guess from an image alone.
  r.claim_checkmark_observed=false
  local main=node(gui,PATH.main)
  if main then
    for _,obj in ipairs(main:GetDescendants()) do
      local n=obj.Name:lower()
      if (n:find('claimed',1,true) or n:find('checkmark',1,true) or n:find('check_mark',1,true))
          and visible(obj,gui) then
        r.claim_checkmark_observed=true
        break
      end
    end
  end
  if r.claim_checkmark_observed and not r.claim_visible then
    r.daily_reward='CLAIMED_INDICATOR'
  end
  r.complete=r.stars~=nil and r.gemstone_progress~=nil and r.gemstone_target~=nil
  if not r.complete then
    r.reason='Star Rewards text unavailable; open Star Rewards and inspect actual Count.Text nodes'
  end
  return r
end
local function same(a,b)
  return a.complete and b.complete and a.stars==b.stars
    and a.gemstone_progress==b.gemstone_progress and a.gemstone_target==b.gemstone_target
    and a.daily_reward==b.daily_reward and a.claim_checkmark_observed==b.claim_checkmark_observed
end
local function clock()
  return os.date('%Y-%m-%d %H:%M:%S')
end
local function val(x)
  return x == nil and '--' or tostring(x)
end
local function console(r, verified)
  local status = verified and 'READY' or 'WAITING'
  local daily = ({AVAILABLE='READY', CLAIMED_INDICATOR='CLAIMED',
    NOT_AVAILABLE_ON_SCREEN='NOT SHOWN', UNKNOWN='UNKNOWN'})[r.daily_reward] or r.daily_reward
  local progress = val(r.gemstone_progress)..'/'..val(r.gemstone_target)
  local message = string.format('[%s] [TRACKSTAT] %s | Stars: %s | Egg: %s | Daily: %s',
    clock(), status, val(r.stars), progress, daily)
  print(message)
end
local function report(r, verified)
  r.verification_status=verified and 'VERIFIED_GUI_STABLE' or 'UNAVAILABLE_OR_UNSTABLE'
  r.last_sync=verified and os.time() or nil
  r.reported_at=os.date('%Y-%m-%d %H:%M:%S')
  local keys={'username','reported_at','verification_status','stars','gemstone_progress',
    'gemstone_target','daily_reward','claim_visible','claim_checkmark_observed',
    'last_sync','source','reason'}
  local lines={'TrackStat v1.3'}
  for _,k in ipairs(keys) do
    table.insert(lines,k..'='..tostring(r[k]==nil and 'unavailable' or r[k]))
  end
  if typeof(writefile)=='function' then
    local ok,err=pcall(function()
      writefile('trackstat_result.txt',table.concat(lines,'\n')..'\n')
      writefile('trackstat_result.json',HttpService:JSONEncode(r))
    end)
    if not ok then warn('['..clock()..'] [TRACKSTAT] Save failed: '..tostring(err)) end
  end
  console(r,verified)
end
print('['..clock()..'] [TRACKSTAT] Started | Scan: 2s')
local lastKey,lastHeartbeat=nil,-math.huge
while true do
  local a=read()
  local verified=a.complete
  if verified then
    for _=2,CFG.samples do
      task.wait(CFG.stable)
      local b=read()
      if not same(a,b) then verified=false; a=b; break end
    end
  end
  local key=table.concat({tostring(a.stars),tostring(a.gemstone_progress),
    tostring(a.gemstone_target),a.daily_reward,tostring(verified)},'|')
  local now=os.clock()
  if key~=lastKey or (not verified and now-lastHeartbeat>=CFG.heartbeat) then
    report(a,verified)
    lastKey=key
    if not verified then lastHeartbeat=now end
  end
  task.wait(CFG.scan)
end
